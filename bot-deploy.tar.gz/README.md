# 🎉 Telegram Birthday Bot

NestJS Telegram бот для автоматических поздравлений с днями рождения.

## 🚀 Возможности

- 🤖 Telegram бот с командами `/start`, `/help`, `/birthdays`, `/today`
- ⏰ Автоматические поздравления каждый день в 11:00
- 👥 Хранение списка людей в массиве (легко заменить на базу данных)
- 📅 Умное определение дней рождения
- 🔧 REST API для управления ботом

## 📋 Требования

- Node.js 18+
- npm или yarn
- Telegram Bot Token

## 🛠️ Установка и настройка

### 1. Установка NestJS CLI (Windows)

```powershell
# Глобальная установка NestJS CLI
npm install -g @nestjs/cli

# Проверка установки
nest --version
```

### 2. Создание проекта (если начинаете с нуля)

```powershell
# Создание нового NestJS проекта
nest new telegram-birthday-bot

# Переход в директорию проекта
cd telegram-birthday-bot
```

### 3. Установка зависимостей

```powershell
# Установка всех необходимых пакетов
npm install @nestjs/schedule @nestjs/config node-telegram-bot-api dayjs

# Установка dev зависимостей
npm install -D @types/node-telegram-bot-api
```

### 4. Настройка переменных окружения

Скопируйте файл `.env.example` в `.env`:

```powershell
copy .env.example .env
```

Отредактируйте `.env` файл:

```env
TELEGRAM_BOT_TOKEN=ВАШ_ТЕЛЕГРАМ_ТОКЕН
TELEGRAM_CHAT_ID=ВАШ_CHAT_ID
PORT=3000
NODE_ENV=development
```

## 🔑 Как получить Telegram Bot Token

1. Найдите в Telegram `@BotFather`
2. Отправьте команду `/newbot`
3. Следуйте инструкциям:
   - Введите имя бота (например: "Birthday Bot")
   - Введите username бота (например: "birthday_helper_bot")
4. BotFather пришлет вам токен вида: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`

## 🔍 Как узнать CHAT_ID

### Способ 1: Через бота @userinfobot

1. Найдите в Telegram `@userinfobot`
2. Отправьте ему любое сообщение
3. Бот ответит вашим Chat ID

### Способ 2: Через API

1. Отправьте любое сообщение вашему боту
2. Перейдите по ссылке:
   ```
   https://api.telegram.org/botВАШ_ТОКЕН/getUpdates
   ```
3. Найдите в ответе `chat.id`

### Способ 3: Через веб-версию Telegram

1. Откройте Telegram Web
2. Зайдите в чат с ботом
3. Смотрите на URL - в нем будет ID чата

## 🚀 Запуск проекта

### Способ 1: Development режим (с hot reload)

```powershell
# Запуск с отслеживанием изменений
npm run start:dev
```

### Способ 2: Production режим

```powershell
# Сборка проекта
npm run build

# Запуск собранного проекта
npm run start:prod
```

### Способ 3: Через ts-node

```powershell
# Установка ts-node если не установлен
npm install -g ts-node

# Запуск напрямую
ts-node src/index.ts
```

## 📱 Команды бота

- `/start` - Приветственное сообщение и информация о боте
- `/help` - Справка по командам
- `/birthdays` - Показать полный список дней рождения
- `/today` - Показать сегодняшних именинников

## 🔧 REST API

Бот также предоставляет HTTP API на порту 3000:

### GET `/bot/status`
Проверить статус бота

### GET `/bot/info`
Получить информацию о боте

### POST `/bot/send`
Отправить тестовое сообщение

```json
{
  "message": "Тестовое сообщение"
}
```

## 👥 Управление списком людей

Редактируйте файл `src/people/people.service.ts` в массиве `people`:

```typescript
private readonly people: Person[] = [
  {
    id: 1,
    name: 'Иван Петров',
    birthDate: '15.06.1990', // Формат: DD.MM.YYYY
    telegramUsername: 'ivan_petrov', // Опционально
  },
  // Добавьте больше людей...
];
```

## ⏰ Автоматические поздравления

Бот автоматически проверяет дни рождения каждый день в 11:00 (по Московскому времени) и отправляет поздравления в указанный чат.

## 📁 Структура проекта

```
src/
├── app.module.ts          # Корневой модуль
├── index.ts               # Точка входа
├── bot/                   # Модуль бота
│   ├── bot.module.ts
│   ├── bot.service.ts     # Логика бота и cron задачи
│   └── bot.controller.ts # HTTP эндпоинты
└── people/                # Модуль управления людьми
    ├── people.module.ts
    └── people.service.ts  # Сервис работы с людьми
```

## 🐛 Отладка

Для отладки используйте:

```powershell
# Запуск в режиме отладки
npm run start:debug
```

Логи бота будут выводиться в консоль.

## 🔄 Замена на базу данных

Для замены массива на базу данных:

1. Установите TypeORM и драйвер БД:
   ```powershell
   npm install @nestjs/typeorm typeorm sqlite3
   ```

2. Создайте entity для Person
3. Замените массив в `people.service.ts` на репозиторий TypeORM
4. Настройте подключение к БД в `app.module.ts`

## 📝 Лицензия

MIT License

## 🤝 Вклад

Pull requests приветствуются!
